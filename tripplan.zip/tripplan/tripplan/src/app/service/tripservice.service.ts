import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Trip } from '../model/trip';
import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TripserviceService {
  url = 'http://localhost:8089/api/trips'
  constructor(private http: HttpClient) { }
  getTripById(tripId:any){
    return this.http.get(`${this.url}/${tripId}`)
  }
  getTrips(){
    return this.http.get(`${this.url}`);
  }

  addTrip(trip: Trip): Observable<Trip> {
    
    if (trip.trip_startDate) {
      trip.trip_startDate = this.formatDate(trip.trip_startDate);
    }
    if (trip.trip_endDate) {
      trip.trip_endDate = this.formatDate(trip.trip_endDate);
    }
    return this.http.post<Trip>(`${this.url}`, trip);
  }

  deleteTrip(tripId: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/${tripId}`);
  }
  removeTripById(tripId:any){
    return this.http.delete(`${this.url}/${tripId}`)
  }
  updateTripById(tripId:any,tripObject:any){
    return this.http.put(`${this.url}/${tripId}`,tripObject)
  }
  private formatDate(date: any): any {
    if (!date) return null;
    if (typeof date === 'string') return date;
    
    const d = new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  searchTripBySourceDestinationType(source:any,destination:any){
    return this.http.get(`${this.url}/search/${source}/${destination}`)

  }
 
}


