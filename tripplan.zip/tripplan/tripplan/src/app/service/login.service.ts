import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { User } from '../model/User';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LoginService implements OnInit{

  constructor(private httpClient:HttpClient) { }
  url="http://localhost:8089/api/users";
  ngOnInit(): void {}
  public isUserLoggedin(){ //if user loggedin it will store in session and it will get whenever 
      let user=sessionStorage.getItem('userId');
    return !(user==null); //returns if the user is there means user is not null
  }
  loginvalidation(user:User):Observable<any>{
    return this.httpClient.post(`${this.url}/login`,user);
  }
  adminloginvalidation(username:string,password:string)
  {
    if((username.trim()==="seethakahema") && (password.trim()==="Manju@143")){
      sessionStorage.setItem('authenticateUser',username)
      return true;
    }
    else
    {
      return false;
    }
}

  }
  



