import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { ForgotpasswordComponent } from './component/forgotpassword/forgotpassword.component';
import { CreateaccountComponent } from './component/createaccount/createaccount.component';
import { HomeComponent } from './component/home/home.component';
import { ProfileComponent } from './component/profile/profile.component';
import { AdminloginComponent } from './component/adminoperations/adminlogin/adminlogin.component';
import { AdminhomeComponent } from './component/adminoperations/adminhome/adminhome.component';
import { WishlistComponent } from './component/wishlist/wishlist.component';
import { ExploretripsComponent } from './component/exploretrips/exploretrips.component';
import { ManagetripsComponent } from './component/adminoperations/managetrips/managetrips.component';
import { ViewuserComponent } from './adminoperations/viewuser/viewuser.component';
import { AddtripsComponent } from './adminoperations/addtrips/addtrips.component';
import { UpdatetripComponent } from './adminoperations/updatetrip/updatetrip.component';
import { UpdateuserComponent } from './adminoperations/updateuser/updateuser.component';
import { BookyourtripComponent } from './component/bookyourtrip/bookyourtrip.component';
import { BooktripComponent } from './component/booktrip/booktrip.component';
import { SuccessComponent } from './component/success/success.component';
import { ManagebookingsComponent } from './adminoperations/managebookings/managebookings.component';


const routes: Routes = [
  {path:"",component:WelcomeComponent},
  {path:"login",component:WelcomeComponent},
  {path:"createaccount",component:CreateaccountComponent},
  {path:"home/:userId",component:HomeComponent},
  {path:"home",component:HomeComponent},
  {path:"forgotpassword",component:ForgotpasswordComponent},
  {path:"profile",component:ProfileComponent},
  {path:"adminlogin",component:AdminloginComponent},
  {path:"adminhome/:name",component:AdminhomeComponent},
  {path:"wishlist",component:WishlistComponent},
  {path:"trips",component:ExploretripsComponent},
  {path:"managetrip",component:ManagetripsComponent},
  {path:"viewusers",component:ViewuserComponent},
  {path:"addtrip",component:AddtripsComponent},
  {path:"updatetrip/:tripId",component:UpdatetripComponent},
  {path:"updateuser/:userId",component:UpdateuserComponent},
  {path:"bookyourtrip",component:BookyourtripComponent},
  {path:"booktrip/:tripId",component:BooktripComponent},
  {path:"success",component:SuccessComponent},
  {path:"managebooking",component:ManagebookingsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
