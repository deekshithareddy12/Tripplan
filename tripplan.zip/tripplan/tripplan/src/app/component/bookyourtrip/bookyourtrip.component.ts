import { Component, OnInit } from '@angular/core';
import { Trip } from '../../model/trip';
import { TripserviceService } from '../../service/tripservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bookyourtrip',
  standalone: false,
  templateUrl: './bookyourtrip.component.html',
  styleUrl: './bookyourtrip.component.css'
})
export class BookyourtripComponent implements OnInit{
  source:any;
  destination:any;
  trip=new Trip();
  trips: Trip[]=[];
  searched:boolean=false;
  constructor(private tripService:TripserviceService,private router:Router){}
  ngOnInit(): void {
    
  }
  searchTrips(){
    this.tripService.searchTripBySourceDestinationType(this.source,this.destination).subscribe(
      (response:any)=>{
        this.trips=response;
        this.searched= true;
      }
      
    )
  }
  BookTrip(trip:any){
    const userId = sessionStorage.getItem('userId');
    this.router.navigate(['booktrip',trip.tripId])
    
  }

}
