import { Component, OnInit } from '@angular/core';
import { Trip } from '../../model/trip';
import { Transportation } from '../../model/Transportation';
import { Wishlist } from '../../model/wishlist';
import { TripserviceService } from '../../service/tripservice.service';
import { WishlistserviceService } from '../../service/wishlistservice.service';
import { LoginService } from '../../service/login.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-exploretrips',
  standalone: false,
  templateUrl: './exploretrips.component.html',
  styleUrl: './exploretrips.component.css'
})
export class ExploretripsComponent implements OnInit {
  trips: Trip[] = [];
  userId!: number;
  message: string = '';

 constructor(
  private tripserviceService: TripserviceService,
  private wishlistService: WishlistserviceService,
  public loginService: LoginService,
  private router: Router
) {}
ngOnInit(): void {
 const storedUserId = sessionStorage.getItem('userId');
    if (storedUserId) {
      this.userId = Number(storedUserId);
      this.fetchTrips();
    } else {
      this.message = 'Please login to explore trips.';
    }
}
fetchTrips(): void {
  this.tripserviceService.getTrips().subscribe(
    (response:any)=>{
      this.trips=response;
    }
  );
}
GoToThisTrip(trip:any){

}
/*addToWishlist(trip: Trip): void {
  const wishlistItem = new Wishlist();
  wishlistItem.dreamTrip = trip.trip_type;
  wishlistItem.createdAt = new Date().toISOString();
  wishlistItem.status = "Saved";
  wishlistItem.user = { userId: this.userId } as any;
  wishlistItem.trip = trip;

  const transportation = new Transportation();
  transportation.mode = "Flight"; // Or any default logic you have
  transportation.createdAt = new Date().toISOString();
  wishlistItem.transportation = transportation;

  this.wishlistService.createWishlist(wishlistItem).subscribe({
    next: () => {
      this.message = `"${trip.trip_type}" added to wishlist successfully.`;
      this.router.navigate(['home']);
    },

    error: (err) => {
      console.error('Error adding to wishlist:', err);
      this.message = 'Failed to add to wishlist.';
    }
  });
}*/
}
