import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDataService } from '../../../service/user-data.service';

@Component({
  selector: 'app-adminhome',
  standalone: false,
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.css'
})
export class AdminhomeComponent implements OnInit {
  constructor(private router:Router,private userDataService:UserDataService){}
  ngOnInit(): void {
    this.checkAdminAccess();
  }
// Method to verify admin access
private checkAdminAccess(): void {
}

manageTrips(): void {
  this.router.navigate(['managetrip']);
}

manageBookings(): void {
  this.router.navigate(['managebooking']);
}
manageUsers(): void {
  this.router.navigate(['viewusers']);
}

navigateToManageTrips() {
this.router.navigate(['/managetrips']);
}
}
