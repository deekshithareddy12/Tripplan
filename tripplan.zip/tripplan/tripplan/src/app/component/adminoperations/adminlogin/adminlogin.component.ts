import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../../service/login.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-adminlogin',
  standalone: false,
  templateUrl: './adminlogin.component.html',
  styleUrl: './adminlogin.component.css'
})
export class AdminloginComponent implements OnInit {
  username:any;
  password:any;
  invalidlogic=false;
  name='';
  ngOnInit(): void {
    
  }constructor(private loginService:LoginService,private router:Router){}
adminLogin(){
  if(this.loginService.adminloginvalidation(this.username,this.password)){
    this.invalidlogic=false;
    this.name=this.username;
    this.router.navigate(['adminhome',this.name]);

  }
  else{
    alert("INVALID LOGIN")
    this.invalidlogic=true;
}
}
}