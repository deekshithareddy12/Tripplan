export class Transportation{
    transportationId:number|null;
    mode:string;
    createdAt:string;
    constructor(){
        this.transportationId=null;
        this.mode="";
        this.createdAt="";
        
    }
}