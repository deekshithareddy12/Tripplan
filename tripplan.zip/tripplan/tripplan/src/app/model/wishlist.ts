import { Trip } from "./trip";
import { User} from "./User";
import { Transportation } from "./Transportation";
export class Wishlist{
    wishlistId: number|null;
    dreamTrip: string;
    createdAt: string;
    status: string;
    user!: User;
  trip!: Trip;
  transportation!: Transportation;
constructor(){
    this.wishlistId=null;
    this.dreamTrip="";
    this.createdAt="";
    this.status="";
    
  }
}
